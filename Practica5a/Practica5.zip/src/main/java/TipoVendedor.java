
/**
 * Enumerado que define los dos tipos de vendedores en plantilla
 * que existen en la tienda
 *
 */
public enum TipoVendedor {
	Junior, Senior
}
