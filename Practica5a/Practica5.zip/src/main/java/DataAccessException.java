@SuppressWarnings("serial")
public class DataAccessException extends Exception {

}
