

@SuppressWarnings("serial")
public class OperacionNoValidaException extends Exception {

	public OperacionNoValidaException(String string) {
		super(string);
	}

}
