

/**
 * Categorias de empleados en la franquicia
 */
public enum Categoria {
	
	ENCARGADO, VENDEDOR, AUXILIAR;
}
